using UnityEngine;

public class BuffUps : MonoBehaviour
{
    public enum PowerUp { Health, Speed }
    public PowerUp powerups;

    public float AmountToGive;

    private PlayerMovement player;

    private void Awake()
    {
        player = FindObjectOfType<PlayerMovement>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            switch (powerups)
            {
                case PowerUp.Health:
                    player.Health += AmountToGive;
                    break;
                    case PowerUp.Speed:
                    player.Speed += AmountToGive;
                    break;
                default:
                    break;
            }

            Destroy(gameObject);
        }

    }
}
