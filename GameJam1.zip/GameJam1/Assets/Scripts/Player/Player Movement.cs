using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpVelocity = 10f;
    private Rigidbody2D body;
    private Animator anim;
    private bool grounded;

    public CoinManager cm;

    public float Health { get; internal set; }
    public float Speed { get; internal set; }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    private void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        body.velocity = new Vector2(horizontalInput * speed, body.velocity.y);

        float scaleFactor = 1.5f;

        if (horizontalInput > 0.01f)
            transform.localScale = new Vector3(scaleFactor, scaleFactor, scaleFactor);
        else if (horizontalInput < -0.01f)
            transform.localScale = new Vector3(-scaleFactor, scaleFactor, scaleFactor);

        if (Input.GetKey(KeyCode.Space) && grounded)
            Jump();

        anim.SetBool("Run", horizontalInput != 0);
        anim.SetBool("Grounded", grounded);
    }

    private void Jump()
    {
        body.velocity = new Vector2(body.velocity.x, jumpVelocity);
        anim.SetTrigger("Jump");
        grounded = false;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
            grounded = true;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            Destroy(other.gameObject);
            cm.coinCount++;
        }
    }

}



